const Discord = require("discord.js");
const client = new Discord.Client();
const mysql = require("mysql");
const request = require("request");
const cheerio = require("cheerio");
const uid = require("uid");
const fileExt = require("file-extension");
const Table = require("ascii-table");
const toMarkdown = require("to-markdown");
const moment = require('moment-timezone');

const propertiesToIgnore = ['cachedAt','ID','registeredAt','linkedTo',
                            'verifyCode','username','ext','verified','linkedAt'];
const baseURL = "https://boardgame-online.com/"
const profilePath = "pages/profile.php?profileuser=";
const searchPath = "req/search_user.php?name=";
const newsPath = "/req/news.php?i=";
const HELP_MESSAGE = "__**Available Commands**__\n`bgo!register <BGOusername>` - Links your BGO Profile with Discord\n" +
                      "`bgo!profile [user]` - If `[user]` is supplied, fetches their profile, else, fetches your profile\n" +
                      "`bgo!achranking [page]` - Displays the 15 linked profiles with the highest Achievement Points, you can look further by providing a `[page]` number\n" + 
                      "`bgo!yahtzee` - Play's yahtzee!\n`bgo!item <itemName>` - Gets info on a BGO item\n`bgo!spell <spellName>` - Gets info on a BGO spell\n" +
                      "`bgo!namesync [discordUser]` - Sync's your name to your BGO username, only moderators can set others nickname's\n" +
                      "`bgo!weather <location>` - Get's current weather conditions for <location>\n`bgo!dadjoke` - Does a random Dad Joke\n" +
                      "`bgo!roleme` - Gives you the `Active BGO Player` role\n" +
                      "`bgo!help` - Displays this help message\n`bgo!status` - Displays the current status of BGO\n\n" +
                      "__Moderator Only__\n" + 
                      "`bgo!forcelink <bgoIDnumber> <discordUser>` - Links an account, skipping verification\n" +
                      "`bgo!unlink <discordUser>` - Unlinks an account\n" + 
                      "`bgo!announce <role> <#channel> <message>` - Pings `@role` with `<message>`, role can be `bgo` or `misc`\n\n" +
                      "__Panda Only__\n`bgo!eval <magic>` - does `<magic>`\n\n" +
                      "*<things> are mandatory arguments, [things] are optional. When searching for a discord user you can either mention them directly or use part of their name.*";
const ROLE_BGO = 1;
const ROLE_GAMER = 2;
const QUOTE_REGEX = /https:\/\/(?:canary.|ptb.)*discord(?:app)*.com\/channels\/(\d*)\/(\d*)\/(\d*)/im;
const JOIN_REGEX = /https:\/\/.*boardgame-online\.com\/g\/game\.php\?(g=\S*)|https:\/\/.*boardgame-online\.com\/*\?page=joingame&(g=\S*)/im;
const DUMB_MEME_REGEX_IM = /\bi(?:'|’)?m\s+(.+)/i;
let DUMB_MEME_LAST = "";
const DUMB_MEME_REGEX_HI = /\bhi\s+(.+)/i;
const SEARCH_API_URL = baseURL + "req/public/search_";
const GAME_API_URL = baseURL + "req/public/game_info.php";
const SEARCH_ENUMS = {item: 'item', dice: 'dice', tombstone: 'tombstone'};
let NEWS_ID = Number.NEGATIVE_INFINITY;

client.login('################################################################ DISCORD TOKEN ################################################################');

let db_config = {
  host     : 'localhost',
  user     : 'bgobot',
  password : '################################################################ DB PASS ################################################################',
  database : 'bgobot',
  supportBigNumbers : true
};

handleDisconnect();

function handleDisconnect() {
  connection = mysql.createConnection(db_config); // Recreate the connection, since
                                                  // the old one cannot be reused.

  connection.connect(function(err) {              // The server is either down
    if(err) {                                     // or restarting (takes a while sometimes).
      console.error('error when connecting to db:', err);
      setTimeout(handleDisconnect, 2000); // We introduce a delay before attempting to reconnect,
    }                                     // to avoid a hot loop, and to allow our node script to
  });                                     // process asynchronous requests in the meantime.
                                          // If you're also serving http, display a 503 error.
  connection.on('error', function(err) {
    if(err.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
      handleDisconnect();                         // lost due to either server restart, or a
    } else {                                      // connnection idle timeout (the wait_timeout
      throw err;                                  // server variable configures this)
    }
  });
}

client.on('ready', () => {
  console.debug('Bot Game Online is ready!');
  client.user.setActivity('Board Game Online', { type: 'PLAYING' });
});

client.on("message", async (message) => {

  if (message.channel.type === "dm"){
    console.log(`${message.author.username}: ${message.content}`);
    message.attachments.forEach(attachment => {
      if (attachment.url){
        console.log(attachment.url);
      }
      else{
        console.log(attachment.proxyURL);
      }
    });
    return;
  }

  let prefix = "bgo!";

  if (message.author.bot) return;

  try {
    updateDailyLoyalty(message);
  }
  catch (exception){
    console.error("OnMessage: Failed to update loyalty");
    console.error(exception);
  }

  try {
    message.formatted = message.content.replace(/!\s*/, '!');
    message.formattedCI = message.formatted.toLowerCase();
    if (message.formattedCI.startsWith(prefix)){
      if (message.formattedCI.startsWith(prefix + "ping")) {
        message.channel.startTyping();
        checkPing(message);
      }
      else if (message.formattedCI.startsWith(prefix + "register")) {
        message.channel.startTyping();
        registerUser(message);
      }
      else if (message.formattedCI.startsWith(prefix + "forcelink")) {
        message.channel.startTyping();
        forceLink(message,false);
      }
      else if (message.formattedCI.startsWith(prefix + "unlink")) {
        message.channel.startTyping();
        forceLink(message,true);
      }
      else if (message.formattedCI.startsWith(prefix + "verify")) {
        message.channel.startTyping();
        verifyUser(message);
      }
      else if (message.formattedCI.startsWith(prefix + 'profile')){
        message.channel.startTyping();
        resolveProfile(message);
      }
      else if (message.formattedCI.startsWith(prefix + 'achranking')){
        message.channel.startTyping();
        outputAchRanking(message);
      }
      else if (message.formattedCI.startsWith(prefix + 'eval')){
        evalCheck(message);
      }
      else if(message.formattedCI.startsWith(prefix + "announce")){
        handleAnnouncement(message);
      }
      else if(message.formattedCI.startsWith(prefix + "yahtzee")){
        message.channel.startTyping();
        yahtzee(message);
      }
      else if(message.formattedCI.startsWith(prefix + "help")){
        message.channel.startTyping();
        sendHelp(message);
      }
      else if(message.formattedCI.startsWith(prefix + "status")){
        message.channel.startTyping();
        checkStatus(message.channel);
      }
      else if(message.formattedCI.startsWith(prefix + "item")){
        message.channel.startTyping();
        bgoSearch(message,SEARCH_ENUMS.item);
      }
      else if(message.formattedCI.startsWith(prefix + "namesync")){
        message.channel.startTyping();
        resolveNameSync(message);
      }
      else if(message.formattedCI.startsWith(prefix + "dadjoke")){
        message.channel.startTyping();
        joke(message);
      }
      else if(message.formattedCI.startsWith(prefix + "spell")){
        message.channel.startTyping();
        bgoSpell(message);
      }
      else if(message.formattedCI.startsWith(prefix + "weather")){
        message.channel.startTyping();
        geocode(message);
      }
      else if(message.formattedCI.startsWith(prefix + "cancel")){
        message.channel.startTyping();
        cancelLink(message);
      }
      else if (message.formattedCI.startsWith(prefix + "roleme")){
        manageRoles(message,ROLE_BGO);
      }
      else if (message.formattedCI.startsWith(prefix + "gamer")){
        manageRoles(message,ROLE_GAMER);
      }
      else if (message.formattedCI.startsWith(prefix + "dice")){
        message.channel.startTyping();
        bgoSearch(message,SEARCH_ENUMS.dice);
      }
      else if (message.formattedCI.startsWith(prefix + "tombstone")){
        message.channel.startTyping();
        bgoSearch(message,SEARCH_ENUMS.tombstone);
      }
      else if (message.formattedCI.startsWith(prefix + "testfunc")){
        testfunc(message);
      }
      else if (message.formattedCI.startsWith(prefix + "tts")){
        tts(message);
      }
    }
  }
  catch (exception){
    console.error(exception);
  }

  let quoteMatch = QUOTE_REGEX.exec(message.content);
  if (quoteMatch) postQuote(message,quoteMatch);

  let joinMatch = JOIN_REGEX.exec(message.content);
  if (joinMatch) handleGameEmbed(message,joinMatch[1] || joinMatch[2]);

  let dumbImMatch = DUMB_MEME_REGEX_IM.exec(message.content);
  if (dumbImMatch) DUMB_MEME_LAST = dumbImMatch[1].toLowerCase();

  let dumbHiMatch = DUMB_MEME_REGEX_HI.exec(message.content);
  if (dumbHiMatch && !dumbImMatch && DUMB_MEME_LAST.includes(dumbHiMatch[1].toLowerCase())){
    await message.react('🇸');
    await message.react('🇹');
    await message.react('🇺');
    await message.react('🇵');
    await message.react('🇮');
    await message.react('🇩');
  }
});

function checkPing(message){
  console.debug("Ping recieved");
  sendAndStop(message.channel,"Getting ping...").then(sentmessage => {
    let ping = sentmessage.createdTimestamp - message.createdTimestamp;
    sentmessage.edit(`Pong! (${ping}ms - Message Latency, ${round(client.ws.ping,2)}ms - API Latency)`);
  });
}

client.on('error', function(error){
  console.error(error);
});

function registerUser(message){
  let userinfo = message.formatted.split(" ",2)[1];
  let channel = message.channel;
  if (userinfo === undefined){
    return sendAndStop(channel,"Missing argument, give me a BGO username");
  }

  userinfo = userinfo.replace(/[^a-z0-9]/gi,'');

  request(baseURL + searchPath + userinfo, function (error, __, rawdata) {
    if (!error) {
      let response = JSON.parse(rawdata);
      let users = response['Users'];

      if (users == undefined || users.length === 0){
        sendAndStop(channel,"No user found with that username :(");
      }
      else if (users.length === 1){
        let userID = users[0].ID;
        let username = users[0].Name;
        let code = uid(16);
        connection.query("INSERT INTO `users` (`ID`,`username`,`verifyCode`," +
                          "`linkedTo`) VALUES (?,?,?,?)",
                          [userID,username,code,message.author.id],
                          function(error,results,fields){
          if (error){
            if (error.code == 'ER_DUP_ENTRY'){
              handleDuplicateRequest(userID, message,username);
            }
            else{
              sendAndStop(channel,"Error inserting account: " + error.sqlMessage);
            }
          }
          else{
            sendAndStop(channel,`Trying to link user ${username} (${userID})?
Please add verification code **${code}** as **the last line** of your BGO profile description
Then use \`bgo!verify ${userID}\``);
          }
        });
      }
      else{
        sendAndStop(channel,"What?");
      }
    }
    else{
      sendAndStop(channel,"Error searching for user:" + error);
    }
  });  
}

function handleDuplicateRequest(userid,message,uname){
  connection.query("SELECT `ID`,`verifyCode`,`linkedTo`,`verified` " +
                    "FROM `users` WHERE `ID` = ? OR `linkedTo` = ?",
                    [userid,message.author.id], function(error,results,fields){
    if (error){
      sendAndStop(message.channel,"Error fetching account from DB: " 
                                                                  + error.sqlMessage);
    }
    else if (results.length > 1) {
      sendAndStop(message.channel,"You have already linked your Discord account or have a pending link you should cancel with `bgo!cancel`");
    }
    else if (results[0].linkedTo != null){
      message.guild.members.fetch(results[0].linkedTo).then(function(guilduser){
        if (results[0].linkedTo == message.author.id && results[0].verified == 1){
          sendAndStop(message.channel,"That BGO account is already linked to you! Use `bgo!profile` to see it");
        }
        else if (results[0].linkedTo == message.author.id){
          sendAndStop(message.channel,`You already have a pending link to a BGO account! Use \`bgo!verify ${results[0].ID}\` to confirm that. Or use bgo!cancel to reset all pending links.`);
        }
        else{
          let linkedUserName = guilduser.nickname || guilduser.user.username;
          sendAndStop(message.channel,`That BGO account is already linked to ${linkedUserName}!`);
        }
      })
      .catch(function(){
        sendAndStop(message.channel,"That BGO account is already linked to a user who has left!");
      });
    }
    else{
      sendAndStop(message.channel,`Trying to link user ${uname} (${userid})?
Please add verification code **${results[0].verifyCode}** as **the last line** of your BGO profile description
Then use \`bgo!verify ${userid}\``);
    }
  });
}

function verifyUser(message){
  let bgoID = message.formatted.split(" ",2)[1];
  let channel = message.channel;
  if (bgoID === undefined){
    return sendAndStop(channel,"Missing argument, give me an ID from `bgo!register`");
  }
  else if (isNaN(bgoID)){
    return sendAndStop(channel,"Invalid argument, give me an ID from `bgo!register`");
  }

  let urlToCheck = baseURL + profilePath + bgoID;
  request(urlToCheck, function (error, response, rawdata) {
    if (!error && response.statusCode == 200) {
      if (rawdata == "User not found"){
        return sendAndStop(channel,"User not found. Did you give an invalid ID?");
      }
      else{
        connection.query("SELECT `verifyCode` FROM `users` WHERE `ID` = ? " +
                        " AND `linkedTo` = ?",
                        [bgoID,message.author.id], function(error,results,fields){
          if (error){
              sendAndStop(channel,`Internal error getting verification code: ${error.sqlMessage}`);
          }
        else{
          if (results.length === 1){
            let vCode = results[0].verifyCode;
            if (rawdata.includes(vCode)){
              linkUser(message.author,channel,bgoID);
            }
            else{
              sendAndStop(channel,`Couldn't find verification code **${vCode}** in that profiles description`);
            }
          }
          else{
            sendAndStop(channel,"You need to do `bgo!register <BGOusername>` first");
          }
        }
      });
      }
    }
    else{
      sendAndStop(channel,`Error getting profile page: ${error}`);
    }
  });
}

function getProfile(userMember,channel,selfAuthor = false){
  let ID = userMember.id || userMember.user.id;
  connection.query("SELECT * FROM `users` WHERE `linkedTo` = ? AND `verified`",
                  [ID],function(error,results,fields){
    
    let bgoUser = results[0];

    if (bgoUser === undefined && !selfAuthor){
      sendAndStop(channel,"User has no linked BGO profile");
    }
    else if (bgoUser === undefined){
      sendAndStop(channel,"You have no linked profile, use `bgo!register <BGOusername>`");
    }
    else{
      if ((new Date() - new Date(bgoUser.cachedAt))
                                    > 120 /*mins*/ * 60 /*secs*/ * 1000 /*ms*/){
        recacheUser(bgoUser.ID,ID).then(newBGOUser => {
          newBGOUser['Average Post Count'] = bgoUser['Average Post Count'];
          userProfile(channel,newBGOUser);
        });
      }
      else{
        userProfile(channel,bgoUser)
      }
    }
  });
}

function userProfile(channel,bgoUser){
  let embed = new Discord.MessageEmbed()
  .setTimestamp()
  .setURL(baseURL + '?page=profile&profileuser=' + bgoUser.ID)
  .setThumbnail(baseURL + 'images/user/' + bgoUser.ID + "." + bgoUser.ext)
  .setTitle(bgoUser.username)
  .setDescription(`${bgoUser.username} has been a registered user since ${bgoUser.registeredAt}`)
  .setFooter('Last fetched at ' + new Date(bgoUser.cachedAt), client.user.avatarURL);

  for (var field in bgoUser) {
    if (propertiesToIgnore.indexOf(field) !== -1 || bgoUser[field] === null) continue;
    embed.addField(field,toMarkdown(String(bgoUser[field])),true);
  }

  switch (bgoUser.Rank) {
    case 'Admin':
      embed.setColor('#C00');
      break;
    case 'Moderator':
      embed.setColor('#4C0B5F');
      break;
    case 'Donator':
      embed.setColor('#B18905');
      break;
    default:
      embed.setColor('#a20c0c')
  }

  sendAndStop(channel,{'embed':embed});
}

function recacheUser(userID,discordUserID){
  return new Promise((resolve,reject) => {
    request(baseURL + profilePath + userID, function (error, response, rawdata) {
      let $ = cheerio.load(rawdata);
      let bgoUser = {};
      bgoUser.ID = userID;
      bgoUser.username = $('.userName ').text();
      bgoUser.Gender = $('td:contains(Gender)').next().text();
      bgoUser.Country = $('td:contains(Country)').next().text();
      bgoUser.registeredAt = $('td:contains(Joined)').next().text();
      bgoUser['Games Finished'] = $('td:contains(Games finished)').next().text();
      bgoUser['Achievement Points'] = $('td:contains(Achievement Points)').next().text();
      bgoUser['Jukebox Points'] = $('td:contains(Jukebox Points earned)').next().text();
      bgoUser['Jukebox Songs Repaired'] = $('td:contains(Jukebox songs repaired)').next().text();
      bgoUser['Players Recruited'] = $('td:contains(Players recruited)').next().text();
      if ($('.userName').hasClass('donator')){
        bgoUser['Donated Amount'] = $('td:contains(Donated)').first().next().text();
        bgoUser.Rank = 'Donator';
      }
      if ($('.userName').hasClass('moderator')){
        bgoUser['Donated Amount'] = $('td:contains(Donated)').first().next().text() || null;
        bgoUser.Rank = 'Moderator';
      }
      else if ($('.userName').hasClass('admin')){
        bgoUser['Donated Amount'] = $('td:contains(Donated)').first().next().text();
        bgoUser.Rank = 'Admin';
      }
      bgoUser['Old Names'] = $('p:contains(Note: these account notices will disappear after one week.)').first().html();
      bgoUser['ext'] = fileExt($('img').attr('src')).substr(0,4).replace("?","");
      bgoUser.cachedAt = new Date();
      saveUser(bgoUser);
      if (bgoUser.Rank != undefined && discordUserID !== false){
        setDonator(discordUserID);
      }
      resolve(bgoUser);
    });
  });
}

async function setDonator(ID){
  let guild = client.guilds.resolve('261241438640013314');
  let member = await guild.members.fetch(ID);
  member.roles.add('261251601207918592');
}

async function saveUser(user){
  connection.query("UPDATE `users` SET `username`=?,`cachedAt`=?,`Gender`=?," +
                    "`Country`=?,`registeredAt`=?,`Games Finished`=?," +
                    "`Achievement Points`=?,`Jukebox Points`=?," + 
                    "`Jukebox Songs Repaired`=?,`Donated Amount`=?," +
                    "`Players Recruited`=?,`Rank`=?,`ext`=?,`Old Names`=? " +
                    "WHERE `ID`=?",
                    [user.username,user.cachedAt,user.Gender,user.Country,
                     user.registeredAt,user['Games Finished'],
                     user['Achievement Points'],user['Jukebox Points'],
                     user['Jukebox Songs Repaired'],user['Donated Amount'],
                     user['Players Recruited'], user.Rank || null,user.ext,
                     user['Old Names'],user.ID],
                     function(error,results,fields){
    if (error){
      console.error(`Error caching profile ${user.username} - ${error.sqlMessage}`);
    }
  });
}

async function forceLink(message,unlink){
  let roleID = message.member.roles.highest.id;
  if (roleID == "261242617654673418" || roleID == "261242638521335811" || roleID == "517034029342523413 "){
    let args = message.formattedCI.split(" ",3);
    let argID = args[1];
    let argMember = args[2];
    try {
      let user = await resolveTarget(message,argMember);
      if (unlink){
        doUnlink(user,message.channel)
      }
      else{
        linkUser(user,message.channel,argID)
      }
    }
    catch (error){
      sendAndStop(message.channel,error.message);
    }
  }
  else{
    sendAndStop(message.channel,"Must be admin/moderator");
  }
}

function linkUser(member,channel,bgoID){
  connection.query("INSERT INTO `users` (`ID`,`linkedTo`,`verified`,`linkedAt`) " +
                  "VALUES (?,?,1,CURDATE()) ON DUPLICATE KEY UPDATE `linkedTo`=?, `verified`=1,`linkedAt`=CURDATE()",
                  [bgoID,member.id,member.id],
                  function(error,results,fields){
      if (error){
        sendAndStop(channel,"Internal error linking user: " + error.sqlMessage);
      }
      else{
        sendAndStop(channel,"Sucessfully linked. Use `bgo!profile` to see your profile. You can now remove the verification code.");
        recacheUser(bgoID,member.id);
      }
  });
}

function doUnlink(member,channel){
  connection.query("DELETE FROM `users` WHERE `linkedTo`=?",
                  [member.id || member.user.id],
                  function(error,results,fields){
    if (error){
      sendAndStop(channel,`Internal error: ${error.sqlMessage}`);
    }
    else{
      sendAndStop(channel,"Sucessfully unlinked.");
    }
  });
}

function cancelLink(message){
  connection.query("DELETE FROM `users` WHERE `linkedTo`=? AND `verified`=0 ",
      [message.author.id],
      function(error){
        if (error){
          sendAndStop(message.channel,"Internal error: " + error.sqlMessage);
        }
        else{
          sendAndStop(message.channel,"Any pending links with your discord account have been removed.");
        }
  });
}

function sendAndStop(channel,message,messageArgs){
  channel.stopTyping(true);
  return channel.send(message,messageArgs);
}

function evalCheck(message){
  if (message.author.id === '################################################################ OWNER ID ################################################################'){
    let arg = message.content.substr(message.content.indexOf(' ')+1);
    try{
      let resp = eval(arg);
      if (typeof(resp) !== "string") resp = require("util").inspect(resp);
      if (resp.length >= 2000) resp = "Response over 2000 characters";
      message.channel.send(resp, {code:"json", disableMentions: 'all'});
    }
    catch (exception){
      message.channel.send(exception.toString());
    }
  }
}

function handleAnnouncement(message){
  let roleID = message.member.roles.highest.id;
  if (roleID == "261242617654673418" || roleID == "261242638521335811" || roleID == "517034029342523413"){
    let args = message.formatted.split(' ');
    let role = args[1].toLowerCase();
    let channel = message.mentions.channels.first();
    let messagePost = args.slice(3).join(' ');
    let roleObj = null;
    if (role == "bgo"){
      roleObj = message.guild.roles.resolve('322467544202084354');
    }
    else if (role == "misc"){
      roleObj = message.guild.roles.resolve('322467649680572418');
    }
    else if (role == "test"){
      roleObj = message.guild.roles.resolve('343222214784450560');
    }
    else{
      sendAndStop(message.channel,"Unknown Role, valid roles are `bgo` and `misc`");
      return;
    }
    if (!channel){
      sendAndStop(message.channel,"Invalid channel");
      return;
    }
    roleObj.setMentionable(true,'Announcement').then(role =>{
      sendAndStop(channel,`<@&${role.id}> ${messagePost}`).then(_ => {
        role.setMentionable(false,'Announcement Done');
      });
    })
  }
}

function yahtzee(message){
  let dice = [...new Array(5)].map(() => Math.round(Math.random() * 5) + 1);
  let first = dice[0];
  let yahtzee = dice.every(function(element){element === first});
  let output = `You rolled ${dice.join(",")}`;
  if (yahtzee){ output += " **Yahtzee!**"}
  sendAndStop(message.channel,output);
}

function checkStatus(channel){
  request(baseURL, function (error, response, rawdata) {
    let embed = new Discord.MessageEmbed();
    embed.setTitle("BGO Status").setURL(baseURL).setColor("FF0000");
    if (error){
      embed.addField("Status","Error");
      embed.addField("Error Message",error.toString());
    }
    else if (response.statusCode !== 200){
      embed.addField("Status","Offline");
      embed.addField("Status Code",response.statusCode,true);
      embed.addField("Status Message",response.statusMessage,true);
    }
    else{
      try{
        let match = /var InitBag = (.*);/g.exec(rawdata)
        let data = JSON.parse(match[1]);
        if (data.Maintenance.text !== undefined){
          embed.addField("Status","Game Creation Offline");
          embed.addField("Maintenance Message",data.Maintenance.text);
        }
        else{
          embed.addField("Status","Online",true).setColor("00FF00");
          embed.addField("Users Online",data.Users.length,true);
          embed.addField("Running Games",data.RunningGames.length,true);
          embed.addField("Players Active",data.Servers[1].ActivePlayers + data.Servers[2].ActivePlayers,true);
          let initState = data.InitialUpdates;
          initState.map(obj => {
            switch (obj.N){
              case "interface":
                embed.addField("Lobby Event",obj.Type,true);
                break;
              case "lobbyvars":
                let formattedDate = moment.unix(obj.PartyTimeUntil).format('ddd MMM Do HH:mm ([CET])');
                embed.addField("Party Time End" + (obj.PartyTimeUntil < obj.ServerTime ? "ed" : ""),formattedDate,true);
            }
          });
          let gamesString = "";
          data.OpenGames.map(function(game){
            gamesString += `[${game.Name} (${game.TotalPlayers}/${game.MaxPlayers})](${baseURL}?page=joingame&g=${game.EncID}&k=${game.EncKey})\n`;
          });
          embed.addField("Open Games",gamesString || "None");
        }
      }
      catch (e){
        embed.addField("Status","Unknown").setColor("#808080");
        embed.addField("Couldn't fetch status",e.message);
        console.error(e);
      }
    }
    sendAndStop(channel,{'embed':embed});
  });
}

function sendHelp(message){
  sendAndStop(message.channel,HELP_MESSAGE);
}

function bgoSearch(message,searchType){
  let itemName = message.formatted.substr(message.formatted.indexOf(' ')+1).trim();
  let options = {
    url: SEARCH_API_URL + searchType + ".php",
    qs: {q: itemName}
  }
  request(options, function (error, __, rawdata) {
    if (!error) {
      let response = JSON.parse(rawdata);
      if (!response.Success){
        sendAndStop(message.channel,"Failed to find any matching item")
      }
      else{
        let embed = new Discord.MessageEmbed()
        .setTimestamp()
        .setThumbnail(response.Image)
        .setTitle(response.Name)
        .setDescription(toMarkdown(response.Tooltip || response.Description,{converters: [{
          filter:'cd',
          replacement: function(content){return content.trim()}
        },{
          filter: 'd-b',
          replacement: function(content){return `\n**Designed by: ${content.trim()}**`}
        }]}))
        .setFooter(`${response.Price} ${searchType === SEARCH_ENUMS.item ? "rupees" : "BGO Coins"}`, "https://cdn.discordapp.com/attachments/261253711089762316/565838328570576896/coin.png")
        .setColor('#a20c0c');

        if (searchType === SEARCH_ENUMS.item){
          embed.addField("Categories",response.Categories)
        }
        sendAndStop(message.channel,{'embed':embed});
      }
    }
    else{
      sendAndStop(message.channel,"Item Query failed" + error);
    }
  });
}

function bgoSpell(message){
  let spellName = message.formatted.substr(message.formatted.indexOf(' ')+1).trim();
  connection.query("SELECT * FROM `spells` WHERE `Name` LIKE ? ORDER BY CASE " +
                    "WHEN `Name` = ? THEN 0 " +  
                    "WHEN `Name` LIKE ? THEN 1 " +
                    "ELSE 2 END, `Name` ASC",
                    ["%" + spellName + "%",spellName,"%" + spellName],
                  function(error,results){
    let minsPastHour = new Date().getMinutes()
    if (results.length){
      let spell = results[0];
      let embed = new Discord.MessageEmbed()
      .setTimestamp()
      .setThumbnail(baseURL + 'g/images/event/spells/' + spell.ID)
      .setTitle(spell.Name)
      .setDescription(toMarkdown(spell.Description))
      .addField("Cost",`${spell.Cost} Rupees`)
      .setFooter(`Spells last cached ${minsPastHour} minutes ago`, client.user.avatarURL)
      .setColor('#a20c0c');
      
      sendAndStop(message.channel,{'embed':embed});
    }
    else{
      sendAndStop(message.channel,`Nothing Found :( New spell? Spells will updated in ${60 - minsPastHour} minutes`);
    }
  });
}

async function nameSync(dUser,message){
  connection.query("SELECT `ID` FROM `users` WHERE `linkedTo`=? AND `verified`",
                  [dUser.id],
                  async function(error,results){
    if (!error){
      let row = results[0];
      if (row != undefined){
        let BGOuser = await recacheUser(row.ID,dUser.id);
        let member = await message.guild.members.fetch(dUser);
        member.setNickname(BGOuser.username,"Synced to BGO");
        sendAndStop(message.channel,"Nickname changed successfully.");
      }
      else{
        sendAndStop(message.channel,"You need to link your profile with `bgo!register <BGOusername>` first.");
      }
    }
    else{
      sendAndStop(message.channel,error.sqlMessage);
    }
  });
}

function joke(message){
  let options = {
    url: 'https://icanhazdadjoke.com/',
    headers: {
      'User-Agent': 'BGO Bot',
      'Accept': 'application/json'
    }
  };
  request(options, function (error, __, rawdata) {
    if (!error) {
      let response = JSON.parse(rawdata);
      let joke = response.joke;
      sendAndStop(message.channel,joke);
    }
  });
}

function geocode(message){
  const query = message.formatted.substr(message.formatted.indexOf(' ')+1).trim();
  request(`https://eu1.locationiq.com/v1/search.php?key=################################################################ LOCATION IQ KEY ################################################################&q=${query}&format=json&limit=1`
          + '&addressdetails=1&normalizeaddress=1&normalizecity=1',
  function(error,_,body){
    if (!error){
      const geoData = JSON.parse(body);
      if (!geoData.error){
        const location = {lat: geoData[0].lat, lon: geoData[0].lon};
        const address = (geoData[0].address.city ? `${geoData[0].address.city}, ` : '') + geoData[0].address.country;
        weather(message,location,address);
      }
      else{
        sendAndStop(message.channel,`😔 ${geoData.error}`);
      }
    }
    else{
      sendAndStop(message.channel,error);
    }
  });
}

function weather(message,locationData,address){
  request(`https://api.openweathermap.org/data/2.5/onecall?lat=${locationData.lat}&lon=${locationData.lon}&exclude=minutely,hourly&appid=################################################################ OPENWEATHERMAP APPID ################################################################&units=metric`,
  function(error,_,body){
    if (!error){
      const weatherData = JSON.parse(body);
      const current = weatherData.current;
      const daily = weatherData.daily[0];
      let precipType = '(none)';
      if (daily.rain) precipType = '(rain)';
      if (daily.snow) precipType = '(snow)';

      const sunrise = moment.unix(daily.sunrise).tz(weatherData.timezone);
      const sunset = moment.unix(daily.sunset).tz(weatherData.timezone);

      const tempF = round(current.temp * 9 / 5 + 32,2);
      const appTempF = round(current.feels_like * 9 / 5 + 32,2);
      const highTempF = round(daily.temp.max * 9 / 5 + 32,2);
      const lowTempF = round(daily.temp.min * 9 / 5 + 32,2);
      const windSpeedMph = round(current.wind_speed / 1.609344,2);
      const niceDescription = current.weather[0].description.charAt(0).toUpperCase()
                            + current.weather[0].description.slice(1);

      let embed = new Discord.MessageEmbed()
      .setTimestamp()
      .setThumbnail(`http://openweathermap.org/img/wn/${current.weather[0].icon}@2x.png`)
      .setTitle(address)
      .setDescription(niceDescription)
      .setFooter(`Powered by OpenWeatherMap & LocationIQ`, "http://openweathermap.org/img/wn/10d@2x.png")
      .addField('Temperature',`${current.temp}°C (${tempF}°F)`,true)
      .addField('Feels Like',`${current.feels_like}°C (${appTempF}°F)`,true)
      .addField('Wind',`${getCardinal(current.wind_deg)} ${current.wind_speed}kph (${windSpeedMph}mph)`,true)
      .addField('Rain Probability',`${daily.pop * 100}% ${precipType}`,true)
      .addField('UV Index',daily.uvi,true)
      .addField('Humidity',`${current.humidity}%`,true)
      .addField('Sunrise','🌅 ' + sunrise.format('hh:mm a'),true)
      .addField('Sunset','🌇 ' + sunset.format('hh:mm a'),true)
      .addField('Daily High',`${daily.temp.max}°C (${highTempF}°F)`,true)
      .addField('Daily Low',`${daily.temp.min}°C (${lowTempF}°F)`,true)
      .addField('Cloud Coverage',`${current.clouds}%`,true);

      if (weatherData.alerts){
        let alert = weatherData.alerts[0].event;
        for (i = 1; i < weatherData.alerts.length; i++){
          alert += `, ${weatherData.alerts[i].event}`
        }
        embed.addField('Weather Warning',alert,true);
      }

      sendAndStop(message.channel,{'embed':embed});
    }
    else{
      sendAndStop(message.channel,error);
    }
  });
}

function round(value, precision) {
  var multiplier = Math.pow(10, precision || 0);
  return Math.round(value * multiplier) / multiplier;
}

//given "0-360" returns the nearest cardinal direction "N/NE/E/SE/S/SW/W/NW/N" 
function getCardinal(angle) {
  //easy to customize by changing the number of directions you have 
  var directions = 8;
  
  var degree = 360 / directions;
  angle = angle + degree/2;
  
  if (angle >= 0 * degree && angle < 1 * degree)
      return "⬆ ";
  if (angle >= 1 * degree && angle < 2 * degree)
      return "↗ ";
  if (angle >= 2 * degree && angle < 3 * degree)
      return "➡ ";
  if (angle >= 3 * degree && angle < 4 * degree)
      return "↘ ";
  if (angle >= 4 * degree && angle < 5 * degree)
      return "⬇ ";
  if (angle >= 5 * degree && angle < 6 * degree)
      return "↙ ";
  if (angle >= 6 * degree && angle < 7 * degree)
      return "⬅ ";
  if (angle >= 7 * degree && angle < 8 * degree)
      return "↖ ";
  //Should never happen: 
  return "N ";
  }

function fetchNews(){
  let todaysTimestamp = moment().tz("Europe/London").hour(11).minute(30).seconds(0).unix();
  try{
    request(baseURL + newsPath + todaysTimestamp, async function (error, __, rawdata) {
      let responseJSON =[];
      try{
        responseJSON = JSON.parse(rawdata);
      } catch (e){
        console.error("Error parsing news data, raw data was:" + rawdata);
      }
      try{
        if (responseJSON.length > 0){
          let channel = client.guilds.resolve('261241438640013314').channels.resolve('503994889831448576');
          let embed = createNewsEmbed();
          for (i = 0; i < responseJSON.length; i++){
            let newsItem = responseJSON[i];
            console.debug(newsItem.Time,newsItem.ID,todaysTimestamp,NEWS_ID,newsItem.Time < todaysTimestamp,newsItem.ID <= NEWS_ID)
            if (newsItem.Time < todaysTimestamp) break;
            if (newsItem.ID <= NEWS_ID) continue;
            if (newsItem.ID > NEWS_ID) NEWS_ID = newsItem.ID;
            console.debug(`NEWS_ID is now ${NEWS_ID}`);
            let newsType = null;
            switch (newsItem.Type){
              case 0: newsType = "News"; break;
              case 1: newsType = "Addition"; embed.setColor('#008800'); break;
              case 2: newsType = "Modification"; embed.setColor('#0000ff'); break;
              case 3: newsType = "Bugfix"; embed.setColor('#ff0000'); break;
              default: newsType = "Unknown"; break;
            }
            let content = toMarkdown(newsItem.Content,{converters: [{
              filter:['img','div'],
              replacement: function(nodeContent){return nodeContent.trim()}
            }]});
            embed.addField("Type", newsType,true)
            .addField("Date",moment.unix(newsItem.Time).format('D MMM YYYY'),true);
            let slicePoint = 0;
            let shortContent = "";
            while ((shortContent = content.slice(slicePoint,slicePoint + 1024)).length > 0) {
              embed.addField("Content",shortContent);
              slicePoint+= 1024;
            }
            if ((i + slicePoint / 1024 - 1) % 7 === 0 && i > 0){
              await sendAndStop(channel,embed);
              embed = createNewsEmbed();
            }
          }
          if (embed.fields.length > 0){
            await sendAndStop(channel,embed);
          }
        }
        else{
        }
      }
      catch(e){
        console.error("ERROR SENDING NEWS",e);
      }
    });
  }
  catch (e){
    console.error("ERROR READING NEWS", e);
  }
}

try{
  setInterval(fetchNews,60000);
}
catch (e){
  console.error("Error posting news",e);
}

function createNewsEmbed(){
  return new Discord.MessageEmbed()
  .setTimestamp()
  .setTitle("New BGO news post!")
  .setThumbnail("https://cdn.discordapp.com/icons/261241438640013314/c34ee121e7725bc0d15b8f1d5adcb271.webp");
}

function updateDailyLoyalty(message){
  let channel = message.channel.id;

  if (message.content.length < 7 && message.attachments.size == 0 ) return;
  if (channel == "279426393845006336" || channel == "478687067791032324" || channel == "480908953383862273" || channel == "494898508365561856" || channel == "511693848854921246") return;

  connection.query("INSERT INTO `loyaltyDaily`(`discordID`, `dailyPoints`) VALUES (?,1)" 
                  +"ON DUPLICATE KEY UPDATE `dailyPoints`=`dailyPoints`+1",
                  message.author.id);
}

async function manageRoles(message,role){
  let member = await message.guild.members.fetch(message);
  if (role === ROLE_BGO){
    if (member.roles.cache.has('512774240173293578')){
      member.roles.remove("512774240173293578","Requested Remove Active Player Role");
    }
    else{
      member.roles.add("512774240173293578","Requested Active Player Role");
    }
  }
  else if (role === ROLE_GAMER){
    if (member.roles.cache.has('519954328681840650')){
      member.roles.remove("519954328681840650","Requested Remove Active Player Role");
    }
    else{
      member.roles.add("519954328681840650","Requested Active Player Role");
    }    
  }
  sendAndStop(message.channel,"Roles updated successfully");
}


function handleGameEmbed(message,gameParams,prevEmbed){
  request(GAME_API_URL + `?${gameParams}`, function (error, __, rawdata) {
    if(!error){
      try {
        let gamedata = JSON.parse(rawdata);
        if (gamedata.Success){
          if (!prevEmbed){
            let embed = new Discord.MessageEmbed()
            .setTimestamp()
            .setURL(gamedata.Link)
            .setTitle(gamedata.Name)
            .setColor('#a20c0c')
            .setFooter(`Game posted by ${message.member.displayName}`, message.author.avatarURL)
            .addField("Status",gamedata.TimeStarted > 0 ? "Closed" : "Open",true)
            .addField("Finish Space",gamedata.Finish,true)
            .addField("Max Players",gamedata.MaxPlayers,true)
            .addField("Action Timer",`${gamedata.ActionTimer} seconds`,true)
            .addField("Seasonal Mode",gamedata.Seasonal || "None",true)
            .addField("Wild Mode",gamedata.WildMode || "None",true)
            .addField("Server",gamedata.ServerRegion,true)
            .addField("Minigames",gamedata.Minigames ? "Enabled" : "Disabled",true)
            .addField("Instant Classes",gamedata.InstantClasses ? "Enabled" : "Disabled",true)
            .addField("Class Selection", gamedata.ClassSelection,true)
            .addField("Survival ",gamedata.Survival ? "Enabled" : "Disabled",true)
            .addField("Expert ",gamedata.Expert ? "Enabled" : "Disabled",true)
            .addField("Created at",moment.unix(gamedata.TimeCreated).format('HH:mm ([CET])'),true)
            .addField("Available Classes ",gamedata.Classes,true)
            .addField("Players",gamedata.Players.join("\n") || "None");

            sendAndStop(message.channel,embed).then(sentmessage =>{
              setTimeout(handleGameEmbed,60000,sentmessage,gameParams,embed);
            });
          }
          else if (prevEmbed && !gamedata.TimeStarted){
            prevEmbed.fields[14].value = gamedata.Players.join("\n") || "None";
            prevEmbed.setTimestamp();
            message.edit(prevEmbed).then( __ => {
              if ((Date.now() / 1000) - gamedata.TimeCreated > 900) return;
              setTimeout(handleGameEmbed,60000,message,gameParams,prevEmbed);
            });
          }
          else if (prevEmbed && gamedata.TimeStarted){
            prevEmbed.fields[0].value = "Closed";
            prevEmbed.setTimestamp();
            message.edit(prevEmbed);
          }
        }
        else {
          message.react("😕");
        }
      }
      catch (e){
        console.error(e);
      }
    }
  });
}

async function resolveProfile(message){
  let split = message.formattedCI.indexOf(' ');
  let arg = message.formattedCI.substr(split+1);
  if (split !== -1){
    resolveTarget(message,arg).then(user => {
      getProfile(user,message.channel);
    }).catch(error => {
      if (error !== "No user found"){
        sendAndStop(message.channel,error);
      }
      else {
        resolveDBProfile(arg).then(user => {
          if ((new Date() - new Date(user.cachedAt))
                  > 120 /*mins*/ * 60 /*secs*/ * 1000 /*ms*/){
            recacheUser(user.ID,false).then(newBGOUser => {
              newBGOUser['Average Post Count'] = user['Average Post Count'];
                userProfile(message.channel,newBGOUser);
              });
          }
          else{
            userProfile(message.channel,user);
          }
        }).catch(error => {
          sendAndStop(message.channel,error);
        });
      }
    });
  }
  else{
    getProfile(message.author,message.channel,true);
  }
}

function resolveUser(guild,arg){
  let term = arg.toLowerCase();
  return new Promise(async (resolve,reject) => {
    await guild.members.fetch();
    let matches = guild.members.cache.filter(function (guildMember){
      let username = guildMember.user.username.toLowerCase();
      let nick = guildMember.nickname ? guildMember.nickname.toLowerCase() : false;
      let uid = guildMember.id;
      return username.includes(term) || nick && nick.includes(term) || uid == term;
    });
    if (matches.size > 1){
      reject("Not specific enough, try using username or @'ing");
    }
    else if (matches.size !== 0){
      resolve(matches.first());
    }
    else{
      reject("No user found");
    }
  });
}

function resolveTarget(message,stringTarget){
  return new Promise((resolve,reject) => {
    if (message.mentions.users !== null && message.mentions.users.size > 1){
      reject("Only mention one user at a time.");
    }
    else if (message.mentions.users !== null && message.mentions.users.size == 1){
      resolve(message.mentions.users.first());
    }
    else{
      resolve(resolveUser(message.guild,stringTarget));
    }
  });
}

async function resolveNameSync(message){
  let roleID = message.member.roles.highest.id;
  let target = message.formattedCI.split(" ",2)[1];

  if (target != undefined){
    try{
      let user = await resolveTarget(message,target);
      if (user.id == message.member.id){
        nameSync(user,message);
      }
      else if (roleID == "261242617654673418" || roleID == "261242638521335811" || roleID == "517034029342523413"){
        nameSync(user,message);
      }
      else{
        sendAndStop(message.channel,"You don't have permission to change other's names");
      }
    }
    catch (error){
      console.error(error);
      sendAndStop(message.channel,"Something went wrong :(");
    }
  }
  else if (target == undefined && message.member.nickname == null){
    nameSync(message.author,message);
  }
  else{
    sendAndStop(message.channel,"You already have a nickname set, try asking a mod/admin")
  }
}

function resolveDBProfile(term){
  return new Promise((resolve,reject) => {
    connection.query("SELECT * FROM `users` WHERE `username` LIKE ? AND verified=1 ORDER BY CASE " +
                      "WHEN `username` = ? THEN 0 " +  
                      "WHEN `username` LIKE ? THEN 1 " +
                      "ELSE 2 END, `username` ASC",
                      ["%" + term + "%",term,term + "%"],
                        function(error,results){
        if (results.length){
          resolve(results[0]);
        }
        else {
          reject("No User Found");
        }
    });
  });
}

function resolveAchTarget(arg,message){
  return new Promise((resolve,reject) => {
    resolveTarget(message,arg).then(user => {
      connection.query("SELECT `ID` FROM `users`" +
                      "WHERE `Achievement Points` IS NOT NULL AND `verified` " +
                      "AND `linkedTo`=?",
                      [user.id],
                      async function(error,results){
        if (results.length){
          resolve(results[0].ID);
        }
        else{
          reject("User has no linked profile")
        }
      });
    }).catch(error => {
      if (error !== "No user found"){
        reject(error);
      }
      else{
        resolveDBProfile(arg).then(user => {
          if ((new Date() - new Date(user.cachedAt))
                  > 120 /*mins*/ * 60 /*secs*/ * 1000 /*ms*/){
            recacheUser(user.ID,false).then(newBGOUser => {
              resolve(user.ID);
            });
          }
          else{
            resolve(user.ID);
          }
        }).catch(error =>{
          reject(error);
        });
      }
    });
  });
}

async function outputAchRanking(message){
  let waitMessage = await message.channel.send("Searching....");
  let arg = message.formatted.split(" ")[1];
  if (!isNaN(arg) || arg === undefined){
    let index = (arg > 1) ? (arg - 1) * 15 : 0;
    outputAchRankingAtIndex(index,waitMessage);
  }
  else{
    resolveAchTarget(arg,message).then(ID => {
      outputAchRankingForUser(ID,waitMessage);
    }).catch(error =>{
      waitMessage.edit(error);
      message.channel.stopTyping();
    });
  }
}

function outputAchRankingForUser(ID,waitMessage){
  connection.query("SELECT `ID`,`linkedTo`,`username`,`Achievement Points` " + 
                    "FROM `users` " + 
                    "WHERE `Achievement Points` IS NOT NULL AND `verified` " +
                    "ORDER BY `Achievement Points` DESC",
                    [],
                    async function(error,results){
    let index = results.findIndex(element => ID == element.ID);
    let startIndex = Math.max(0,index - 7);
    let endIndex = index + Math.max(8,15 - (index + startIndex));
    let resultsRange = results.slice(startIndex, endIndex);
    outputAchRankingTable(resultsRange,waitMessage,startIndex);
  });
}

function outputAchRankingAtIndex(index,waitMessage){
  connection.query("SELECT `linkedTo`,`username`,`Achievement Points` " + 
                  "FROM `users` " + 
                  "WHERE `Achievement Points` IS NOT NULL AND `verified` " +
                  "ORDER BY `Achievement Points` DESC " + 
                  "LIMIT 15 OFFSET ?",
                  [index],
  async function(error,results){
    if (error){
      sendAndStop(waitMessage.channel,"Error fetching ranking " + error.sqlMessage);
    }
    else{
      if (results.length > 0){
        outputAchRankingTable(results,waitMessage,index);
      }
      else{
        sendAndStop(waitMessage.channel,"You've gone past the end!");
      }
    }
  });
}

async function outputAchRankingTable(results,waitMessage,offset){
  let table = new Table();
  table.setHeading('Position','Discord Username','BGO Username',
          'Achievement Points');

  for (let index in results) {
    let row = results[index];
    let rankNo = ++index + offset;
    let user = await client.users.fetch(row.linkedTo);
    try{
      let member = await waitMessage.guild.members.fetch(user);
      let name = member.nickname||member.user.username;
      table.addRow(rankNo,name,row.username,row['Achievement Points']);
    }
    catch (e){
      table.addRow(rankNo,"[Member Left]",row.username,row['Achievement Points']);
    }
  }

  waitMessage.edit(table.toString(),{code:'js'})
  waitMessage.channel.stopTyping();

  let filter = reaction => reaction.emoji.name == "⬅" || reaction.emoji.name == "➡";
  let collector = waitMessage.createReactionCollector(filter);
  collector.on('collect', (r,user) => {
    if (user.id == waitMessage.author.id || !r.me) return;
    if (r.emoji.name == "⬅"){
      outputAchRankingAtIndex(Math.max(0,offset-15),waitMessage);
      collector.stop();
      waitMessage.reactions.removeAll();
    }
    else if (r.emoji.name == "➡"){
      outputAchRankingAtIndex(offset + 15,waitMessage);
      collector.stop();
      waitMessage.reactions.removeAll();
    }
  });

  if (offset > 0){
    await waitMessage.react('⬅');
  }
  if (results.length === 15){
    await waitMessage.react('➡');
  }
}

function testfunc(message){
}

function postQuote(message,quoteMatch){
  let messageURL = quoteMatch[0];
  let channel = quoteMatch[2];
  let messageID = quoteMatch[3];

  try {
    message.guild.channels.resolve(channel).messages.fetch(messageID).then(quoteMessage => {
      let response = new Discord.MessageEmbed();
      response.setTimestamp(quoteMessage.createdTimestamp);
      if (quoteMessage.embeds.length > 0 && quoteMessage.embeds[0].type == "rich"){
        let quoteEmbed = quoteMessage.embeds[0];
        response.setTitle(quoteEmbed.title)
        .setDescription(quoteEmbed.description)
        .setColor(quoteEmbed.hexColor)
        .setURL(quoteEmbed.url)
        .setImage(quoteEmbed.image && quoteEmbed.image.url)
        .setThumbnail(quoteEmbed.thumbnail && quoteEmbed.thumbnail.proxyURL)
        .fields = quoteEmbed.fields;
      }
      else{
        response.setTitle("Quoted Message")
        .setFooter(quoteMessage.member && quoteMessage.member.displayName || quoteMessage.author.username,quoteMessage.author.avatarURL)
        .setDescription(quoteMessage.content)
        .setColor(quoteMessage.member && quoteMessage.member.displayHexColor || '#7289da')
        .setURL(messageURL);
        if (quoteMessage.attachments.size > 0){
          let urlsToAttach = [];
          quoteMessage.attachments.forEach(attachment => {urlsToAttach.push(attachment.proxyURL)});
          response.attachFiles(urlsToAttach);
        }
      }
      message.channel.send({embed: response, disableMentions: 'all'});
    });
  }
  catch (e){
    console.error(e);
  }
}

function tts(message){
  let encodedQuery = encodeURIComponent(message.content.replace("nian!tts",""));
  let url = "http://tts.cyzon.us/tts?text=" + encodedQuery;

  let voiceChannel = message.member.voice.channel;

  voiceChannel.join().then(connection => {
    const dispatcher = connection.play(url, { seek: 0, volume: 1 });
    dispatcher.on('finish', () => {
      voiceChannel.leave();
    });
  })
  .catch(console.error);
}